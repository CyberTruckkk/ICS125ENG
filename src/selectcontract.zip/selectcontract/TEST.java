package selectcontract;

public class TEST {
    public static void main(String[] args) {
        String s = "passska";
        String c = "passs";
        System.out.println(s.contains(c));
    }
}
