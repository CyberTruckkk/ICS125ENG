/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package domparserdemo;

import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;


/**
 *
 * @author C0533031
 */
public class DOMParserDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
         File inputFile = new File("C:\\Users\\C0533031\\OneDrive - Camosun College\\Documents\\NetBeansProjects\\calcdemo\\DOMParserDemo\\src\\domparserdemo\\input.xml");
         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
         Document doc = dBuilder.parse(inputFile);
         doc.getDocumentElement().normalize();
         System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
         NodeList nList = doc.getElementsByTagName("student");
         
         for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);
            System.out.println("\nCurrent Element :" + nNode.getNodeName());
            
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
               Element eElement = (Element) nNode;
               String rolNo = eElement.getAttribute("rolno");
               System.out.println("Student roll no : " + rolNo);
               
               System.out.println("First Name : "  + eElement.getElementsByTagName("name").item(0).getTextContent());
             }
         }
      } catch (Exception e) {  e.printStackTrace();   }
   }
}
