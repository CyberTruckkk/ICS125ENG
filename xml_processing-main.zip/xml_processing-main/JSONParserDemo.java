package domparserdemo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.*;
  
public class JSONParserDemo 
{
    public static void main(String[] args) throws FileNotFoundException, IOException 
    {
        try {
            Object obj = new JSONParser().parse(new FileReader("C:\\Users\\C0533031\\OneDrive - Camosun College\\Documents\\NetBeansProjects\\calcdemo\\DOMParserDemo\\src\\domparserdemo\\myjson.json"));
            JSONObject jo = (JSONObject) obj;
            String firstName = (String) jo.get("name");
            String lastName = (String) jo.get("lastName");
            System.out.println(firstName);
            System.out.println(lastName);
            int age = Integer.parseInt((String)jo.get("age"));
            System.out.println(age);
            
            Map address = ((Map)jo.get("address"));
            Iterator<Map.Entry> itr1 = address.entrySet().iterator();
            while (itr1.hasNext()) {
                Map.Entry pair = itr1.next();
                System.out.println(pair.getKey() + " : " + pair.getValue());
            }
            
            JSONArray ja = (JSONArray) jo.get("phoneNumbers");
            Iterator itr2 = ja.iterator();
            while (itr2.hasNext())  {
                itr1 = ((Map) itr2.next()).entrySet().iterator();
                while (itr1.hasNext()) {
                    Map.Entry pair = itr1.next();
                    System.out.println(pair.getKey() + " : " + pair.getValue());
                }
            }
        } catch (ParseException ex) {
            Logger.getLogger(JSONParserDemo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
